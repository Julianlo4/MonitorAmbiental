#define DHT11_PIN      A15
const int photocellPin = A10;
#define LED_GREEN A7
#define LED_RED A5
#define LED_BLUE A6
#define BUZZER A14
